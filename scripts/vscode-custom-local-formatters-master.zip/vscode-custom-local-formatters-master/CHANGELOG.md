# Change Log

All notable changes to the "custom-local-formatters" extension will be documented in this file.

Format based off of [Keep a Changelog](http://keepachangelog.com/).

## [Unreleased]

## v0.0.6 - 2021-09-27

### Improvments
- Dependency updates

## v0.0.5 - 2021-09-27

### Improvments
- Dependency updates

## v0.0.4 - 2020-05-23

### Improvments
- Documentation updates

## v0.0.3 - 2020-05-23

### Improvments
- Documentation updates

## v0.0.2 - 2020-05-23

### Improvments
- Better logging

## v0.0.1 - 2020-05-23

### Features
- Initial release